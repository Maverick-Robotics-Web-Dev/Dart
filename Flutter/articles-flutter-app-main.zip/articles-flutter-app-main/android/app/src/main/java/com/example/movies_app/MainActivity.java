package com.example.ny_times;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
