const String svgPath = "assets/svg_images/";
const String imagePath = "assets/images/";
const String defaultStr = "-";
